-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 26, 2024 at 12:40 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `moon`
--

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `source` varchar(70) NOT NULL,
  `price` float NOT NULL,
  `category` varchar(40) NOT NULL,
  `section` varchar(40) NOT NULL,
  `quantity` int(11) NOT NULL,
  `cartId` float NOT NULL,
  `new` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `source`, `price`, `category`, `section`, `quantity`, `cartId`, `new`) VALUES
(1, 'Basic-fit-T-shirt', '../images/Man/T-shirts/Basic-fit-T-shirt-1.jpg', 7.99, 'T-shirts', 'Man', 25, 3.1, 1),
(2, 'Basic-fit-T-shirt', '../images/Man/T-shirts/Basic-fit-T-shirt-2.jpg', 7.99, 'T-shirts', 'Man', 13, 3.2, 1),
(3, 'Basic-fit-T-shirt', '../images/Man/T-shirts/Basic-fit-T-shirt-3.jpg', 7.99, 'T-shirts', 'Man', 12, 3.3, 1),
(4, 'Heavy Weight T-Shirt', '../images/Man/T-shirts/Heavy-weight-T-shir-1.jpg', 12.99, 'T-shirts', 'Man', 10, 3.4, 0),
(5, 'Heavy Weight T-Shirt', '../images/Man/T-shirts/Heavy-weight-T-shirt-2.jpg', 12.99, 'T-shirts', 'Man', 5, 3.5, 0),
(6, 'Ottoman Long Sleeve T-Shirt', '../images/Man/T-shirts/Ottoman-long-sleeve-T-shirt-1.jpg', 17.99, 'T-shirts', 'Man', 7, 3.6, 0),
(7, 'Ottoman Long Sleeve T-Shirt', '../images/Man/T-shirts/Ottoman-long-sleeve-T-shirt-2.jpg', 17.99, 'T-shirts', 'Man', 8, 3.7, 0),
(8, 'Ottoman Long Sleeve T-Shirt', '../images/Man/T-shirts/Ottoman-long-sleeve-T-shirt-3.jpg', 17.99, 'T-shirts', 'Man', 10, 3.8, 0),
(9, 'Oversize T-Shirt', '../images/Man/T-shirts/Oversized-short-sleeve-T-shirt-1.jpg', 12.99, 'T-shirts', 'Man', 17, 3.9, 0),
(10, 'Oversize T-Shirt', '../images/Man/T-shirts/Oversized-short-sleeve-T-shirt-2.jpg', 12.99, 'T-shirts', 'Man', 3, 3.11, 0),
(11, 'Baggy Jeans', '../images/Man/Jeans/Baggy-jeans-1.jpg', 29.99, 'Jeans', 'Man', 13, 2.1, 1),
(12, 'Baggy Jeans', '../images/Man/Jeans/Baggy-jeans-2.jpg', 29.99, 'Jeans', 'Man', 11, 2.2, 1),
(13, 'Baggy Jeans', '../images/Man/Jeans/Baggy-jeans-3.jpg', 29.99, 'Jeans', 'Man', 9, 2.3, 1),
(14, 'Baggy Skater Cargo Jeans', '../images/Man/Jeans/Baggy-skater-cargo-jeans.jpg', 35.99, 'Jeans', 'Man', 3, 2.4, 1),
(15, 'Baggy Skater Cargo Jeans', '../images/Man/Jeans/Baggy-skater-cargo-jeans.jpg', 35.99, 'Jeans', 'Man', 3, 2.4, 0),
(16, 'Basic Slim Jeans', '../images/Man/Jeans/Basic-slim-jeans-1.jpg', 19.99, 'Jeans', 'Man', 0, 2.5, 0),
(17, 'Carpenter Jeans', '../images/Man/Jeans/Carpenter-jeans-1.jpg', 24.99, 'Jeans', 'Man', 6, 2.6, 0),
(18, 'Carpenter Jeans', '../images/Man/Jeans/Carpenter-jeans-2.jpg', 24.99, 'Jeans', 'Man', 4, 2.7, 0),
(19, 'Dark Blue Standard Jeans', '../images/Man/Jeans/Dark-blue-standard-jeans.jpg', 19.99, 'Jeans', 'Man', 0, 2.9, 0),
(20, 'Jogger Jeans', '../images/Man/Jeans/Jogger-jeans-1.jpg', 15.99, 'Jeans', 'Man', 7, 2.11, 0),
(21, 'Basic Cargo Joggers', '../images/Man/Joggers/Basic-cargo-joggers-1.jpg', 27.99, 'Joggers', 'Man', 5, 4.1, 0),
(22, 'Basic Cargo Joggers', '../images/Man/Joggers/Basic-cargo-joggers-2.jpg', 27.99, 'Joggers', 'Man', 11, 4.2, 0),
(23, 'Basic Cargo Joggers', '../images/Man/Joggers/Basic-cargo-joggers-3.jpg', 27.99, 'Joggers', 'Man', 10, 4.3, 0),
(24, 'Basic Hoodie Tracksuit', '../images/Man/Joggers/Basic-hoodie-tracksuit-1.jpg', 35.99, 'Joggers', 'Man', 30, 4.4, 1),
(25, 'Basic Hoodie Tracksuit', '../images/Man/Joggers/Basic-hoodie-tracksuit-2.jpg', 35.99, 'Joggers', 'Man', 25, 45, 1),
(26, 'Basic Hoodie Tracksuit', '../images/Man/Joggers/Basic-hoodie-tracksuit-3.jpg', 35.99, 'Joggers', 'Man', 10, 4.6, 0),
(27, 'Zip Up Hoodie Tracksuit', '../images/Man/Joggers/Basic-zip-up-hoodie-tracksuit-1.jpg', 39.99, 'Joggers', 'Man', 8, 4.7, 1),
(28, 'Zip Up Hoodie Tracksuit', '../images/Man/Joggers/Basic-zip-up-hoodie-tracksuit-2.jpg', 39.99, 'Joggers', 'Man', 5, 4.8, 0),
(29, 'Ripped Jogger Jeans', '../images/Man/Joggers/Ripped-jogger-jeans-1.jpg', 24.99, 'Joggers', 'Man', 3, 4.9, 0),
(30, 'Pack Of Two Joggers', '../images/Man/Joggers/Pack-of-2joggers-2.jpg', 25.99, 'Joggers', 'Man', 10, 4.11, 0),
(31, 'Lightweight Quilted Jacket', '../images/Man/Jacket/Jacket-01.jpg', 35.99, 'Jackets', 'Man', 25, 1.1, 1),
(32, 'Lightweight Quilted Jacket', '../images/Man/Jacket/Jacket-02.jpg', 35.99, 'Jackets', 'Man', 25, 1.2, 1),
(33, 'Lightweight Quilted Jacket', '../images/Man/Jacket/Jacket-03.jpg', 35.99, 'Jackets', 'Man', 20, 1.3, 1),
(34, 'Shearling Hooded Jacket', '../images/Man/Jacket/Jacket-04.jpg', 39.99, 'Jackets', 'Man', 6, 1.4, 0),
(35, 'Faux Shearling Jacket', '../images/Man/Jacket/Jacket-05.jpg', 35.99, 'Jackets', 'Man', 18, 1.5, 1),
(36, 'Combined Puffer Jacket', '../images/Man/Jacket/Jacket-06.jpg', 45.99, 'Jackets', 'Man', 4, 1.6, 0),
(37, 'Double Faced Black Jacket', '../images/Man/Jacket/Jacket-07.jpg', 59.99, 'Jackets', 'Man', 16, 1.7, 0),
(38, 'Double Faced Black Jacket', '../images/Man/Jacket/Jacket-07.jpg', 59.99, 'Jackets', 'Man', 16, 1.7, 1),
(41, 'STWD Puffer Jacket', '../images/Man/Jacket/Jacket-09.jpg', 47.99, 'Jackets', 'Man', 10, 1.9, 0),
(42, 'Denim Jacket Fur Collar', '../images/Man/Jacket/Jacket-11.jpg', 39.99, 'Jackets', 'Man', 0, 1.11, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(40) NOT NULL,
  `surname` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `password` varchar(40) NOT NULL,
  `roli` varchar(40) NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `surname`, `email`, `password`, `roli`) VALUES
(121, 'Anila', 'Hoti', 'anilahoti@gmail.com', 'anila123', 'admin'),
(509, 'Endrit', 'Musaj', 'endritmusaj@gmail.com', 'endrit12', 'user');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=819;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
